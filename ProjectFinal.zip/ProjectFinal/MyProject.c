#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = OFF
#pragma config LVP = OFF

#define DIR_MASK  (LEFT_FWD | LEFT_REV | RIGHT_FWD | RIGHT_REV)  // DIR_MASK = 0b11110000

#define FAST_SPEED 85
#define MED_SPEED   80
#define SLOW_SPEED 60

#define STOP 0


#define right_pwm CCPR1L
#define left_pwm  CCPR2L


#define LEFT_SENSOR   0b00000100   // RD2
#define RIGHT_SENSOR  0b00001000   // RD3


#define RIGHT_IR   0b00100000  //RB5 -> right IR
#define LEFT_IR  0b00000100  //RA2 -> left IR

#define LEFT_FWD   0b00010000   // RC4=1, RC5=0
#define LEFT_REV   0b00100000   // RC4=0, RC5=1
#define RIGHT_FWD  0b01000000   // RC6=1, RC7=0
#define RIGHT_REV  0b10000000   // RC6=0, RC7=1

#define DARK_THRESHOLD 170
#define BUZZER 0b00010000  //RB4 outputs high to turn on the buzzer

#define SERVO_FLAG 0b01000000 //RB6
#define TRIGGER 0b00000010  //Trigger is on RB1
#define ECHO 0b00000100 //Echo is on RB2


 //these FLAGs will be used in the ISR to determine the pulse width
unsigned char FORWARD_FLAG=1; //This flag is initially HIGH because the ultrasonic must be initially forward
unsigned char LEFT_FLAG=0;
unsigned char RIGHT_FLAG=0;

unsigned char servo_timer=1; //timer_Servo generates a PWM with pulsewidth (1ms /1.5ms /2ms) according to the direction of rotation
unsigned char num_of_overflows=0; //used for servo pwm
unsigned char update_servo_flag=0;   //when this flag is set/HIGH, PWM signal will be reflected on RB6 (servo motor of flag)
unsigned char buzzer_beep=0;         // this variable is set when we want the buzzer to beep (parking)
unsigned char  obstacle_mode=0;
unsigned int num_of_int=0;             //16 bits 65535
unsigned int num_of_overflows_buzzer=0;
unsigned char start=0;
unsigned char T1overflow;


void interrupt()
{
    if (INTCON&0b00000100)          // TMR0IF used for 3s delay
    {
        INTCON=INTCON&~0b00000100;   // Clear TMR0IF

        //Reload Timer0
        TMR0=0x00;
        if (!start)
        {
          num_of_int++;
          if (num_of_int>5859)    //0.512*10^-3*5860=3.00032s -> this generates a 3.00032 delay
          {
              num_of_int=0;
              start=1;
          }
        }
        if (update_servo_flag)
        {
           num_of_overflows++;
           if(FORWARD_FLAG)
           {
            if (servo_timer ==1 )
            {
             if(num_of_overflows>2) //HIGH for 1.5ms (0.512*10^-3*3 )
             {
               PORTB=PORTB & ~SERVO_FLAG; //set RB6 to LOW (PWM on servo motor of flag)
               servo_timer=0;
               num_of_overflows=0; //reset num_of_overflows
             }
            }
            else
            {
             if( num_of_overflows>35) //continue LOW until reaching 18.5 (36 overflows) (0.512*10^-3*36)
             {
               PORTB=PORTB | SERVO_FLAG; //set RB6 to HIGH
               servo_timer=1;
               num_of_overflows=0;

             }
            }
           }
           else if (RIGHT_FLAG)
           {
            if (servo_timer ==1 )
            {
             if(num_of_overflows>3) //HIGH for 2ms
             {
               PORTB=PORTB & ~SERVO_FLAG; //set RB6 to LOW
               servo_timer=0;
               num_of_overflows=0; //reset num_of_overflows
             }
            }
            else    //if LOW
            {
             if( num_of_overflows>34) //continue LOW until reaching 18ms
             {
               PORTB=PORTB | SERVO_FLAG; //set RB6 to HIGH
               servo_timer=1;
               num_of_overflows=0;
             }
            }
           }
           else       // LEFT_FLAG
           {
            if (servo_timer ==1 )
            {
             if(num_of_overflows>1) //HIGH for 1ms
             {
               PORTB=PORTB & ~SERVO_FLAG; //set RB6 to LOW
               servo_timer=0;
               num_of_overflows=0; //reset num_of_overflows
             }
            }
            else    //if LOW
            {
             if( num_of_overflows>36) //continue LOW until reaching 19ms
             {
               PORTB=PORTB | SERVO_FLAG; //set RB6 to HIGH
               servo_timer=1;
               num_of_overflows=0;
             }
            }
           }
        }
        if ( buzzer_beep)
        {
         num_of_overflows_buzzer++;
         if(num_of_overflows_buzzer>1999) //2000*0.512*10^-3=1.024 (approx. 1s)
         {
          num_of_overflows_buzzer=0;
          if (PORTB & BUZZER) //if buzzer is active for 1 s -> turn it off
          {
           PORTB=PORTB & ~BUZZER; //turn off buzzer
          }
          else //buzzer is inactive -> turn it on
          {
            PORTB=PORTB | BUZZER; //turn off buzzer
          }
         }
        }
    }
    if ( PIR1 & 0b00000001)    //TMR1 overflowed
    {
     PIR1 = PIR1 & ~0b00000001; // clear TMR1IF
     T1overflow++;
    }

}


void forward(void)
{
    PORTC = (PORTC & (~DIR_MASK)) | (LEFT_FWD | RIGHT_FWD);
    right_pwm = FAST_SPEED;
    left_pwm  = MED_SPEED;
}

void turn_left(void)
{
    PORTC = (PORTC & (~DIR_MASK)) | (LEFT_FWD | RIGHT_FWD);
    right_pwm = FAST_SPEED;
    left_pwm  = SLOW_SPEED;
}

void turn_right(void)
{
    PORTC = (PORTC & (~DIR_MASK)) | (LEFT_FWD | RIGHT_FWD);
    right_pwm = SLOW_SPEED;
    left_pwm  = FAST_SPEED;
}

void backward(void)
{
    PORTC = (PORTC & (~DIR_MASK)) | (LEFT_REV | RIGHT_REV);
    right_pwm = FAST_SPEED;
    left_pwm  = MED_SPEED;
}
void stop()
{

    PORTC = (PORTC & (~DIR_MASK)) | (LEFT_FWD | RIGHT_FWD);
    right_pwm = STOP;
    left_pwm  = STOP;

}


unsigned char read_LDR()
{
  int i;
  unsigned int val;
  for (i=0;i<40;i++); //this creates a 20us delay, the recommended acquisition time in the data sheet is 19.72 us
  ADCON0 = ADCON0 | 0b00000100; // start A/D Conversion
  while(ADCON0 & 0b00000100); // wait for A/D Conversion to finish
  val = ((ADRESH<<8)+ADRESL); // analog result of LDR;
  if (val>DARK_THRESHOLD)
  {
     return 1; //return True if dark
  }
  return 0;
}

void tunnel(void)
{
 PORTB=PORTB|BUZZER; //turn on the buzzer
 while( read_LDR() )
 {
    if ((PORTD&LEFT_SENSOR ) && (PORTD&RIGHT_SENSOR))   //both sensors see white
        {
         forward();
        }
    if (!(PORTD&RIGHT_SENSOR) && (PORTD&LEFT_SENSOR ))  //only right sensor sees black
        {
         turn_right();
        }
    if  (!(PORTD&LEFT_SENSOR ) && (PORTD&RIGHT_SENSOR))  //only left sensor sees black
        {
         turn_left();
        }
 }
 PORTB=PORTB&~BUZZER; //turn off the buzzer
 obstacle_mode  =1;
}


void move_slowly(int duration)   //this function is used to check if the sensors still see black after a delay
{
  int i,j;

  for (i = 0; i < duration; i++)
  {
   for ( j=0;j<6500;j++)
   {
      PORTC = (PORTC & (~DIR_MASK)) | (LEFT_FWD | RIGHT_FWD);
      right_pwm = SLOW_SPEED;
      left_pwm  = SLOW_SPEED;
   }
  }
}

 void sharp_left(int duration)      //this function is used on the t-intersection
{
  int i,j;

  for (i = 0; i < duration; i++)
  {
   for ( j=0;j<6500;j++)
   {
      PORTC = (PORTC & (~DIR_MASK)) | (LEFT_REV) |( RIGHT_FWD);
      right_pwm = 150;
      left_pwm  = 150;
   }
  }
}

 void sharp_right(int duration)      //this function is used on the t-intersection
{
  int i,j;

  for (i = 0; i < duration; i++)
  {
   for ( j=0;j<6500;j++)
   {
      PORTC = (PORTC & (~DIR_MASK)) | (LEFT_FWD) |( RIGHT_REV);
      right_pwm = 150;
      left_pwm  = 150;
   }
  }
}

void raise_flag()
{
  int i,j;
  update_servo_flag=1;
  FORWARD_FLAG=1;
  RIGHT_FLAG=0;
  LEFT_FLAG=0;
  for (i = 0; i < 100; i++)        //delay for 500 ms
  {
   for (j = 0; j < 3333; j++);
  }

   update_servo_flag = 0;   // stop servo PWM
}
int ultrasonic_read(void)
{
    int i,distance;
    unsigned int time_taken;
    T1overflow=0;
    TMR1L = 0;
    TMR1H = 0;  //reload tmr1 with 0

    PORTB = PORTB | TRIGGER; // set TRIGGER to HIGH
    for (i=0;i<20;i++);  //this creates a delay of 10 micro s it is the time taken for the trigger to finish
    PORTB = PORTB & ~TRIGGER;  // set TRIGGER to LOW

    while (!(PORTB & ECHO));
    T1CON = T1CON | 0b00000001;    // start Timer1

    while (PORTB & ECHO);
    T1CON = T1CON & 0b11111110;    // stop Timer1
    time_taken =((TMR1H<<8) | TMR1L) + (T1overflow*65536);;
    distance = time_taken/58;
    return distance;
}


void obstacle_avoidance()
{
    int i;
    int dist = ultrasonic_read();
    if (dist > 0 && dist < 5)
    {
        stop();
        backward();
        for(i=0;i<5000;i++);
        stop();
        return;
    }
    if ((PORTB & RIGHT_IR)) // right free
    {
     PORTD = PORTD |  0b00000001;    //turn on blue LED
     turn_right();
     for(i=0;i<3500;i++);
     PORTD = PORTD & ~0b00000001;    //turn off blue LED
    }
    else
    {
     turn_left();
     for(i=0;i<3500;i++);
     }
}




void wall_centering()
{
 int i;
 while((PORTD&LEFT_SENSOR ) || (PORTD&RIGHT_SENSOR))
 {

    if ((PORTA & LEFT_IR) && (PORTB & RIGHT_IR))  //centered between the two walls
    {
        forward();
        break;
    }
    else if ((PORTA & LEFT_IR) && !(PORTB & RIGHT_IR))  // too close to right wall -> move left
    {
        turn_left();
        for( i=0;i<3500;i++);
    }
    else if (!(PORTA & LEFT_IR) && (PORTB & RIGHT_IR))  // too close to left wall -> move right
    {
        turn_right();
        for( i=0;i<3500;i++);
    }
    else      // no walls detected
    {
        forward();
    }
 }
}

void park(void)
{
   int i,j;
  buzzer_beep=1; //start beeping the buzzer
  sharp_right(2);
  stop();
  buzzer_beep=0; //stop the buzzer beep
  PORTB =PORTB & ~BUZZER;
  raise_flag();
  PORTD=PORTD & ~0b00010000; //turn off the LED
}




void main(void)
{
    int dist,i;
    TRISA = 0x05;   //RA2 and RA0 input (LDR and IR)
    TRISB = 0x24;   // RB2 and RB5 input  (IR and Echo ultrasonic)
    TRISC = 0x00;   // RC4�RC7 outputs (H-bridge)
    TRISD = 0x0C;   // RD2, RD3 inputs (line sensors)

    PORTA = 0x00;
    PORTB = 0x00;
    PORTC = 0x00;
    PORTD = 0x00;

    INTCON = 0b11100000;  // enable GIE + TMR0IE  + PEIE
    OPTION_REG = 0b11000001; // apply a PS of 4 to TMR0 so that it overflows every 0.512ms
    PIE1 = 0b00000001; //enable TMR1 interrupt

    PR2   = 249;          // PWM period, max value of PR2
    T2CON = 0b00000111;   // Timer2 ON, prescaler 1

    T1CON=0b00010000;  //a prescalar of 2 is applied to TMR1

    CCP1CON = 0b00001100; // CCP1 PWM mode
    CCP2CON = 0b00001100; // CCP2 PWM mode

    ADCON0 = 0b11000001; // A/D converter module is turned on and the clock is Fosc/16
    ADCON1 = 0b11001110; // only RA0 is analog the rest are digital & right justified
    while (!start)
    {
        asm nop;
    }
    PORTD=PORTD | 0b00010000; //turn on the LED
    forward();

    while (!obstacle_mode) //LINE FOLLOWING MODE +  CONTINUOUSLY CHECKS IF IN TUNNEL
    {   unsigned int i,j;
        if ((PORTD&LEFT_SENSOR ) && (PORTD&RIGHT_SENSOR))   //both sensors see white
        {
         forward();
        }
        else if (!(PORTD&RIGHT_SENSOR) && (PORTD&LEFT_SENSOR ))  //only right sensor sees black
        {
         turn_right();
        }
        else if (!(PORTD&LEFT_SENSOR ) && (PORTD&RIGHT_SENSOR))  //only left sensor sees black
        {
         turn_left();
        }

        else if (!(PORTD & LEFT_SENSOR) && !(PORTD & RIGHT_SENSOR))   // T-intersection
        {
            stop();

            for (j=0; j<5; j++)          // small delay
                for (i=0; i<60000; i++);

           dist = ultrasonic_read();

            if (dist > 0 && dist < 25)
                PORTA |= 0b00000010;   // red LED on */
                sharp_left(2);
                PORTA = PORTA & ~0b00000010;   // turn off red LED
            /* if (dist > 0 && dist < 150)
            {


                if (!(PORTA & LEFT_IR))   // left side free
                {
                    PORTD = PORTD | 0b00000001;   // turn blue LED on
                    sharp_left(1);
                    PORTD = PORTD & ~0b00000001;   // turn blue LED off
                }
                else
                {
                    sharp_right(1);
                }
            } */

        }

        if(read_LDR())
        {
           tunnel();
        }
    }

    //lines after this will be executed when leaving the tunnel
    forward();
    while ((PORTD&LEFT_SENSOR ) && (PORTD&RIGHT_SENSOR))
    {
     dist=ultrasonic_read();
     if (dist>0 && dist<25)
     {
      //stop();
      PORTA = PORTA | 0b00000010;  //turn on red LED
      obstacle_avoidance();
      PORTA = PORTA & ~0b00000010;  //turn off red LED
     }
     if((PORTA & LEFT_IR)) //close to an obstacle to the left
     {
        PORTD = PORTD | 0b00000001;   // turn blue LED on
        turn_right();
        for(i=0;i<3500;i++);
        PORTD = PORTD & ~0b00000001;   // turn blue LED off
     }
     if((PORTB & RIGHT_IR))//too close to an obstacle to the right
     {
        PORTD = PORTD | 0b00000001;   // turn blue LED on
        turn_left();
        for(i=0;i<3500;i++);
        PORTD = PORTD & ~0b00000001;   // turn blue LED off
     }

     else
     {
     forward();
     }
    }

    while( 1)
    {
     if ((PORTD&LEFT_SENSOR ) && (PORTD&RIGHT_SENSOR))   //both sensors see white
        {
         forward();
        }
     if (!(PORTD&RIGHT_SENSOR) && (PORTD&LEFT_SENSOR ))  //only right sensor sees black
        {
         turn_right();
        }
     if (!(PORTD&LEFT_SENSOR ) && (PORTD&RIGHT_SENSOR))  //only left sensor sees black
        {
         turn_left();
        }

     if (!(PORTD&LEFT_SENSOR ) && !(PORTD&RIGHT_SENSOR))   //both see black
        {
          move_slowly(6);

           if ( (!(PORTD&LEFT_SENSOR ) && !(PORTD&RIGHT_SENSOR)) ) //both sensors still see black ->  T-Intersection or parking area
           {
              park();
              break;
           }
        }
    }

}